export { default } from "./NewComment";
