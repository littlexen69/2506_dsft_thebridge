export { default } from "./Post";
