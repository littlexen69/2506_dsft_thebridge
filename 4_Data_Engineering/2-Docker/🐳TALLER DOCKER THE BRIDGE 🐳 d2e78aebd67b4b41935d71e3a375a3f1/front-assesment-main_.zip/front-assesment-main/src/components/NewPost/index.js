export { default } from "./NewPost";
